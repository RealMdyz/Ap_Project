import MyProject.*;

public class Main {
    public static void main(String[] args) {
        MyProjectData.getProjectData();
        new MyProject();
    }
    // FazBandi : Har_Roz_Ye_Meghdar_Bezana

}
