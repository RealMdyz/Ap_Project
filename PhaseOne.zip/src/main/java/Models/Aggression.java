package Models;

public interface Aggression {
    void aggression();
}
