package Models;

public interface Moveable {
    void move(int xLimit, int yLimit);
}
