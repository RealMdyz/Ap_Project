package Config;

public class BlackOrbConfig {
    public int xCenter;
    public int yCenter;

    public BlackOrbConfig() {
    }
}
