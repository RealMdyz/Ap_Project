package Models;

public interface LocalRouting {
    void localRouting(int xEpsilon, int yEpsilon);
}
