package Models;

public enum AttackType {
    LASER,
    RANGED,
    AOE,
    DROWN,
    MELEE,
    REDUCE_FOR_INCREASE,
    NOT_FOUND
}
