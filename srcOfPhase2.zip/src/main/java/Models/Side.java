package Models;

public enum Side {
    LEFT,
    RIGHT,
    UP,
    DOWN,
}
