package Controller.BossFight;

public class BossFightIntersection {

}
