package MyProject;

import Models.Constant;
import View.Menu.LoginPageShare;

public class MyProject {

    public MyProject(){
        Constant constant = new Constant();
        new LoginPageShare(constant);

    }
}
