package Config;

public class EpsilonConfig {
    public EpsilonConfig() {
    }

    public int x, y;
}
