package Models;

public enum EntityType {
    EPSILON,
    ENEMY,
    NOF_FOUND
}
