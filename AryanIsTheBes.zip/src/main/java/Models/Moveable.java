package Models;

public interface Moveable {
    void move();
}
