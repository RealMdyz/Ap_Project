package Config;

public class EnemyConfig {
    public int x;
    public int y;
    public String type;

    public EnemyConfig() {
    }
}
