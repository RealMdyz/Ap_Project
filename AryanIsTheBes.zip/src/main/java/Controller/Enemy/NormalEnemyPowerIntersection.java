package Controller.Enemy;

public class NormalEnemyPowerIntersection {
    public NormalEnemyPowerIntersection(){

    }
}
